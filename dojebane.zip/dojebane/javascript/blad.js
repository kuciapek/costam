
 function blad()  { document.getElementById('blad').addEventListener('click', function() {
    alert('Błąd: Coś poszło nie tak!');
});
}